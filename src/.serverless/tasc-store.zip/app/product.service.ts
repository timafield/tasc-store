import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Product } from './store/product.model';
import { Observable } from 'rxjs/Observable';
import { isDevMode } from '@angular/core';
//import { PRODUCTS } from './store/market'

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  products: Product[];

  getProducts(): Observable<Product[]> {
    url = (isDevMode()) ? 'http:' : 'http://localhost:4000/products'
    return this.http.get<Product[]>(url);
    //return PRODUCTS;
  }
}
